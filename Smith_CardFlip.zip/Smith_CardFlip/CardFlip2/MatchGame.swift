//
//  MatchGame.swift
//  CardFlip2
//
//  Created by Joel Hollingsworth on 9/26/16.
//  Copyright © 2016 Joel Hollingsworth. All rights reserved.
//
//  Edited by Christy Smith on 10/01/16
//  Copyright © 2016 Christy Smith. All rights reserved.

import UIKit

/**
 * This is the Model for the Match Game.
 */
class MatchGame {
    
    let deck = Deck()
    var flips = 0
    var score = 0
    var message = "Welcome!"
    var matched: [Int] = []
    
    var previous = -1
    
    var matrix: [Card] = []
    
    init() {
        // draw 16 random cards
        for _ in 1...16 {
            matrix.append(deck.drawRandomCard())
        }
    }
    
    /*
     * Called when a card is tapped.
     */
    func flipCardUp(_ which: Int) {
        
        // only need to do something if card is facing down
        if matrix[which].isShowing == false {
            
            // flip up
            matrix[which].isShowing = true
            
            // update values/text
            flips += 1
            score -= 1
            message = matrix[which].text
            
            if (previous == -1){
                previous = which
            }
            else if (previous != -1) {
                if(matrix[which].value == matrix[previous].value){
                    score += 17
                    matrix[which].isMatched=true
                    matrix[previous].isMatched=true
                    matched.append(which)
                    matched.append(previous)
                    message = "Match on \(matrix[which].value)"
                    previous = -1
                    
                }
                else if(matrix[which].suit == matrix[previous].suit){
                    score += 5
                    matrix[which].isMatched=true
                    matrix[previous].isMatched=true
                    matched.append(which)
                    matched.append(previous)
                    message = "Match on \(matrix[which].suit)"
                    previous = -1
                }
                else{
                // flip over the previous card
                matrix[previous].isShowing = false
                // remember the last card tapped
                previous = which
                }
            }
            
            
        }
        
    }
    
    /*
     * Flip the card over regardless of Status
     */
    func reset(_ which: Int) -> UIImage {
        return matrix[which].reset()
    }
    
    /*
     * Return the current image for a particular Card
     */
    func getImage(_ which: Int) -> UIImage {
        return matrix[which].getImage()
    }
    
    
}
